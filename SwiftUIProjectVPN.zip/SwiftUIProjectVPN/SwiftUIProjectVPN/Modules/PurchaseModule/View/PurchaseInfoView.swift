//
//  PurchiseInfoView.swift
//  SwiftUIProjectVPN
//
//  Created by Levon Shaxbazyan on 05.05.24.
//

import SwiftUI

struct PurchaseInfoView: View {
   
    enum Constants {
        static let calendar = "calendar"
    }
    
    var purchaseInfo: PurchaseInfo
    
    var body: some View {
        VStack {
            ZStack {
                Image(Constants.calendar)
                VStack {
                    Text(purchaseInfo.days)
                        .font(.system(size: 36))
                        .bold()
                }.padding(.top, 30)
            }
            Text("\(purchaseInfo.type) (\(purchaseInfo.duration)) \(purchaseInfo.price) RUB")
                .foregroundColor(.white)
                .font(.system(size: 16))
            Button {
                print("weak")
            } label: {
                Text("Buy")
                    .foregroundColor(.white)
                    .font(.system(size: 16))
                    .frame(width: 100, height: 48)
                    .background(Color.blue)
                    .cornerRadius(8)
            }
        }
    }
    
}
