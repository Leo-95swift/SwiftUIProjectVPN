//
//  PurchaseView.swift
//  SwiftUIProjectVPN
//
//  Created by Levon Shaxbazyan on 05.05.24.
//

import SwiftUI

/// Предстовление экрана предложений
struct PurchaseView: View {
    
    // MARK: = Constants
    
    enum Constants {
        
        static let title = "Privacy Matters"
        static let description = "Protect your online activities with VPN Plus"
        static let calendar = "calendar"
        
    }
    
    // MARK: - @State Private Properties
    
    // @State private var isToggleOn = false
    private var viewModel = PurchaseViewModel()
    
    // MARK: - Body
    
    var body: some View {
        ZStack {
            Color(.black)
                .ignoresSafeArea(edges: .top)
            VStack {
                titleView
                ScrollView {
                    VStack(spacing: 35) {
                        PurchaseInfoView(
                            purchaseInfo: viewModel
                                .fetchPurchases()[0]
                        )
                        
                        PurchaseInfoView(
                            purchaseInfo: viewModel
                                .fetchPurchases()[1]
                        )
                        
                        PurchaseInfoView(
                            purchaseInfo: viewModel
                                .fetchPurchases()[2]
                        )
                        
                    }
                }
            }
        }
    }
    
    // MARK: - UI Elements
    
    var titleView: some View {
        VStack {
            Text(Constants.title)
                .foregroundColor(.white)
                .frame(width: 300, height: 30, alignment: .center)
                .font(.system(size: 24))
                .bold()
            
            Text(Constants.description)
                .foregroundColor(.white)
                .frame(width: 340, height: 30, alignment: .center)
                .font(.system(size: 16))
        }
    }
    
}

#Preview {
    PurchaseView()
}
