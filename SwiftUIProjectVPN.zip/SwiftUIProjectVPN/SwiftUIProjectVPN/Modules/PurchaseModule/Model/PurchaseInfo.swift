//
//  PurchaseInfo.swift
//  SwiftUIProjectVPN
//
//  Created by Levon Shaxbazyan on 05.05.24.
//

import Foundation

struct PurchaseInfo {
    let days: String
    let type: String
    let duration: String
    let price: Int
}
