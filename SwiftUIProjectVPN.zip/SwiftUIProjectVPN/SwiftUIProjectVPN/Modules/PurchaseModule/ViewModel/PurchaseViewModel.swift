//
//  PurchaseViewModel.swift
//  SwiftUIProjectVPN
//
//  Created by Levon Shaxbazyan on 05.05.24.
//

import Foundation

/// вью модель для экрана услуг
final class PurchaseViewModel {
    
    enum Constants {
        static let vacation = "vacation"
        static let standart = "standart"
        static let standartPlus = "standartPlus"
        
        static let vacationDays = "7"
        static let standartDays = "30"
        static let standartPlusDays = "90"
        
        static let vacationDuration = "7 days"
        static let standartDuration = "1 month"
        static let standartPlusDuration = "1 year"
        
        static let vacationPrice = 99
        static let standartPrice = 179
        static let standartPlusPrice = 279
        
    }
    
    func fetchPurchases() -> [PurchaseInfo] {
        let purchases: [PurchaseInfo] = [
        PurchaseInfo(
            days: Constants.vacationDays,
            type: Constants.vacation,
            duration: Constants.vacationDuration,
            price: Constants.vacationPrice
        ),
        
        PurchaseInfo(
            days: Constants.standartDays,
            type: Constants.standart,
            duration: Constants.standartDuration,
            price: Constants.standartPrice
        ),
        
        PurchaseInfo(
            days: Constants.standartPlusDays,
            type: Constants.standartPlus,
            duration: Constants.standartPlusDuration,
            price: Constants.standartPlusPrice
        )]
        
        return purchases
    }
}
