//
//  SwiftUIProjectVPNApp.swift
//  SwiftUIProjectVPN
//
//  Created by Levon Shaxbazyan on 04.05.24.
//

import SwiftUI

@main
struct SwiftUIProjectVPNApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
